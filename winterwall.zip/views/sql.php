<?php
    $SQLservername='localhost';
    $SQLusername='login';
    $SQLpassword='root';
?>